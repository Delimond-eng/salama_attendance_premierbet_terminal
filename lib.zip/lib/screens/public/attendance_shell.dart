import 'package:flutter/material.dart';

import 'attendance_kiosk_mockups.dart';

class AttendanceShell extends StatelessWidget {
  const AttendanceShell({super.key});

  @override
  Widget build(BuildContext context) {
    return const KioskMockupsGallery();
  }
}
